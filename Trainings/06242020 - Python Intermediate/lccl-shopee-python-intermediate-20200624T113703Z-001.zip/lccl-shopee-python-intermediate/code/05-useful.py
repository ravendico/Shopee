# by LCCL Coding Academy, www.LccLcoding.com
# for Shopee Code League 2020

# SOME USEFUL THINGS
# ======================
print()

# ternary operation


# zip


# filter
n = [11, 12, 33, 43, 55, 66, 76, 88]
# filter(odd, n)


# map
# map(remainder, n)


# reduce
from functools import reduce
# reduce(mult, n)


# string joins


# string translation



print()